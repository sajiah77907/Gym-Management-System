class DataBase:
    """
    This class is mapping external oracle database with python using the external module.
    """ 
    
    def __init__(self, username:str, password:str, port:int, host:str='localhost', service:str='orcl'):
        """
        This method is the constructor method and will be called automatically when object is created.

        Args:
            username (str): string containing databae username
            password (str): string containing database password
            port (int): integeral value containing port number for database access
            host (str, optional): string containing the host service of database. Defaults to 'localhost'.
            service (str, optional): string containing the database name. Defaults to 'orcl'.

        Raises:
            EnvironmentError: when connection is not established
        """ 
               
        self.__connection = self.__connect(f'{username}/{password}@{host}:{port}/{service}')
        if self.__connection is None:
            raise EnvironmentError('No connection object found')
        print('**** Database Connection Opened ****')


    def __del__(self):
        """
        This method is destructor and will be called whenever the object is removed or deleted.
        """        
        
        if self.__connection is not None:
            self.__connection.close()
            print('**** Database Connection Closed ****')
        else:
            print('**** Object Destructor ****')


    def __str__(self):
        """
        This method will be called when the object of class is printed.

        Returns:
            str: string for printing the object
        """        
        return 'ORACLE PL/SQL DATABASE HANDLER CLASS'


    def __connect(self, dsn:str):
        """
        This method will try to establish the connection with external oracle database.
        If connection established it will point to databae else return null object.

        Args:
            dsn (str): string having combination of username, password, host and pluggable database

        Returns:
            connection: connection object (if connection established)
        """        
        
        import oracledb as orc
        connection = None
        try:
            connection = orc.connect(dsn)
            print(connection.version)   
        except orc.Error as error:
            print(error)
        finally:
            return connection


    def __table(self, access):
        if access.lower() == 'manager':
            return 'GYM_MANAGER'
        elif access.lower() == 'trainee':
            return 'TRAINEE'
        elif access.lower() == 'trainer':
            return 'TRAINER'
        return 'NONE'
    
    
    def executer(self, query:str):
        """
        This method will take any SQL query and execute it.

        Args:
            query (str): multiline string having SQL query

        Returns:
            cursor: cursor after executing the query
        """        
        
        cursor = self.__connection.cursor()
        cursor.execute(query)
        return cursor
    
    def insertRecord(self, tid:int, email:str, password:str, name:str, address:str, mid:int, joinDate:str, access:str, sal:int=..., fee:int=...):
        cursor = self.__connection.cursor()
        if self.__table(access) == 'TRAINER':
            cursor.callproc('INS_TRAINER_PROCEDURE', [tid,name,sal,address,joinDate,mid,email,password])
            # cursor.execute(f""" INSERT INTO TRAINER(TRAINER_ID,TRAINER_NAME,SALARY,ADDRESS,TRAINER_DATE_JOINED,MANAGER_ID,USER_EMAIL,USER_PASSWORD) VALUES ({tid}, '{name}', {sal}, '{address}', '{joinDate}', {mid}, '{email}', '{password}') """)
        elif self.__table(access) == 'TRAINEE':
            cursor.callproc('INS_TRAINEE_PROCEDURE', [tid,name,fee,address,joinDate,mid,email,password])
            # cursor.execute(f""" INSERT INTO TRAINEE(TRAINEE_ID,TRAINEE_NAME,SECURITY_FEE,ADDRESS,TRAINEE_DATE_JOINED,MANAGER_ID,USER_EMAIL,USER_PASSWORD) VALUES ({tid}, '{name}', {fee}, '{address}', '{joinDate}', {mid}, '{email}', '{password}')  """)
        self.__connection.commit()
        return dict(tid=tid, email=email, password=password, name=name, address=address, sal=sal, fee=fee, mid=mid, date=joinDate, access=access)
    
    def getCredential(self, passString:str):
        if passString == 'password':
            cursor = self.__connection.cursor().execute(""" SELECT * FROM login_view """)
            return [dict(email=row[0], password=row[1], access=row[2], tid=row[3]) for row in cursor]
        return []
    
    def getRecord(self, rtype:str, tid:int=None):
        cursor = self.__connection.cursor()
        if tid is not None:
            cursor.execute(f""" SELECT * FROM {self.__table(rtype)} WHERE {rtype.upper()}_ID = {int(tid)} """)
        else:
            cursor.execute(f""" SELECT * FROM {self.__table(rtype)} """)
        try:
            if rtype.lower() == 'manager':
                return [dict(mid=row[0],name=row[1], age=row[2], gender=row[3], address=row[4], level=row[5], email=row[6], password=row[7]) for row in cursor]
            elif rtype.lower() == 'trainer':
                return [dict(tid=row[0],name=row[1], salary=row[2], address=row[3], date=row[4], mid=row[5], email=row[6], password=row[7]) for row in cursor]
            elif rtype.lower() == 'trainee':
                return [dict(tid=row[0],name=row[1], fee=row[2], address=row[3], date=row[4], mid=row[5], email=row[6], password=row[7]) for row in cursor]
        except TypeError:
            pass
        return []
        
    def getItems(self):
        cursor = self.__connection.cursor()
        cursor.execute(f""" SELECT * FROM EQUIPMENT """)
        return [dict(eid=row[0], typename=row[1], cost=row[2], quantity=row[3], delivery=row[4], maintainance=row[5]) for row in cursor]
    
    def getDiet(self):
        cursor = self.__connection.cursor()
        cursor.execute(f""" SELECT * FROM DIET_VIEW """)
        return [dict(did=row[0], name=row[1], description=row[2]) for row in cursor]
    
    def getWorkout(self):
        cursor = self.__connection.cursor()
        cursor.execute(f""" SELECT * FROM workout_view """)
        return [dict(cid=row[0], time=row[1], size=row[2], tid=row[3], name=row[4], ctype=row[5]) for row in cursor]
    
    def addWorkout(self, cid:int, trid:int, tid:int, size:int, time:str, ctype:str):
        cursor = self.__connection.cursor()
        cursor.execute(f""" INSERT INTO TABLE WORKOUT_CLASS(cid, trid, tid, size, time, ctype) VALUES ({cid}, {trid}, {tid}, {size}, '{time}', '{ctype}')""")
        return dict(cid=cid, tid=tid, trid=trid, size=size, time=time, ctype=ctype)

    def getTId(self,rtype):
        cursor = self.__connection.cursor()
        cursor.execute(f""" SELECT {rtype.upper()}_ID FROM {self.__table(rtype)} """)
        return [row[0] for row in cursor]
    