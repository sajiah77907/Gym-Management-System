from django.shortcuts import render
import DB as dB

# Create your views here.

def trainerView(request, tid:int=None):
    db = dB.DataBase(username='system',password='sajiahSE20$',port='1521')
    name = db.getRecord('trainer',tid)[0].get('name')
    del(db)
    # name = 'SaJia'
    return render(request,'trainer/trainer.html', context=dict(name=name))

    
def classPlanView(request):
    lst = []
    db = dB.DataBase(username='system',password='sajiahSE20$',port='1521')
    lst = db.getWorkout()
    del(db)
    # lst = [
    #     dict(cid=3, tid=1, name='Faris', size=2, time='10:30', ctype='Upper Body'),
    #     dict(cid=3, tid=3, name='Fozan', size=1, time='12:30', ctype='Upper Arms'),
    #     dict(cid=3, tid=1, name='Fahim', size=2, time='15:30', ctype='Chest Weight')
    # ]
    return render(request,'trainer/classplan.html',context=dict(items=lst))  
    
