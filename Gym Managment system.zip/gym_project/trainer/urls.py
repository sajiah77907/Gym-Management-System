from django.urls import path
from . import views

urlpatterns = [
    path('<int:tid>/',views.trainerView,name='Trainer'),
    path('classplan',views.classPlanView,name='ClassPlan'),
    
]