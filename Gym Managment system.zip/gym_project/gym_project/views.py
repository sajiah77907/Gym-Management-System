from django.http import HttpResponseRedirect

def landingPageView(request):
    return HttpResponseRedirect('/home')