from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.contrib import messages
import DB as dB

# Create your views here.
def checkEmail(email:str):
    import re
    if not re.match(string=email,pattern='.*@.*\..*'):
        return False
    return True

def trainerSignupView(request):
    return render(request, 'manager/trainersignup.html')  


def managerView(request, tid=None):
    db = dB.DataBase(username='system',password='sajiahSE20$',port='1521')
    name = db.getRecord('manager',tid)[0].get('name')
    del(db)
    # name = 'SaJia'
    return render(request,'manager/manager.html', context=dict(name=name))   


def traineeMemberView(request):
    lst = []
    db = dB.DataBase(username='system',password='sajiahSE20$',port='1521')
    try:
      lst = db.getRecord('trainee')
    except TypeError:
        pass
    del(db)
    # lst=[
    #     dict(tid=40,email='abc@abc.com', password='123', name='Faris', address='RWP', fee=4000, mid=10, date='12-JAN-23'),
    #     dict(tid=20,email='456@abc.com', password='456', name='Qasim', address='ISB', fee=4500, mid=10, date='15-NOV-22'),
    #     dict(tid=50,email='xyz@abc.com', password='789', name='Fahim', address='TXL', fee=4000, mid=10, date='19-DEC-21')
    # ]
    return render(request,'manager/traineemember.html', context=dict(items=lst))  

    
def trainerMemberView(request):
    lst = []
    db = dB.DataBase(username='system',password='sajiahSE20$',port='1521')
    try:
      lst = db.getRecord('trainer')
    except TypeError:
        pass
    del(db)
    # lst=[
    #     dict(tid=40,email='abc@abc.com', password='123', name='Faris', address='RWP', salary=14000, mid=10, date='12-JAN-23'),
    #     dict(tid=20,email='456@abc.com', password='456', name='Qasim', address='ISB', salary=14500, mid=10, date='15-NOV-22'),
    #     dict(tid=50,email='xyz@abc.com', password='789', name='Fahim', address='TXL', salary=14000, mid=10, date='19-DEC-21')
    # ]
    return render(request,'manager/trainermember.html', context=dict(items=lst))  

    
def equipmentView(request):
    lst = []
    db = dB.DataBase(username='system',password='sajiahSE20$',port='1521')
    try:
      lst = db.getItems()
    except TypeError:
        pass
    del(db)
    # lst=[
    #     dict(eid=50, typename='PUSH UP MACHINE', cost=50000, quantity=4, delivery='12-JAN-23', maintainance='YES'),
    #     dict(eid=80, typename='CHEST WEIGHT MACHINE', cost=55000, quantity=3, delivery='15-JAN-25', maintainance='YES'),
    #     dict(eid=90, typename='LEG WEIGHT MACHINE', cost=40500, quantity=6, delivery='19-NOV-21', maintainance='NO')
    # ]
    return render(request,'manager/equipment.html', context=dict(items=lst))  

def addTrainerView(request):
    email = request.POST.get('email')
    password = request.POST.get('password')
    name = request.POST.get('name')
    address = request.POST.get('address')
    sal = request.POST.get('sal')
    joinDate = request.POST.get('date')
    if checkEmail(email):
        from random import randint
        fee=None
        access='trainer'
        mid='7'
        tid = randint(1,9999)
        db = dB.DataBase(username='system',password='sajiahSE20$',port='1521')
        while tid in  db.getTId('trainer'):
            tid = randint(1,9999)
        db.insertRecord(tid, email, password, name, address, mid, joinDate, access, sal, fee)
        del(db)
        messages.success(request, f'Your {access.lower()} {name} is created successfully')
        return HttpResponseRedirect(f'/manager/{mid}')
    messages.error(request, 'The credentials entered are not valid')
    return HttpResponseRedirect('/manager/signup')

