from django.urls import path
from . import views

urlpatterns = [
    path('<int:tid>/',views.managerView,name='Manager'),
    path('alltrainee',views.traineeMemberView,name='TraineeMember'),
    path('alltrainer',views.trainerMemberView,name='TrainerMember'),
    path('equipment',views.equipmentView,name='Equipment'),
    path('addtrainer',views.addTrainerView,name='AddTrainer'),
    path('trainersignup',views.trainerSignupView,name='TrainerSignup')
]
