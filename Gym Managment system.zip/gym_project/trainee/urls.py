from django.urls import path
from . import views

urlpatterns = [
    path('<int:tid>/',views.traineeView,name='Trainee'),
    path('workout',views.workoutView,name='Workout'),
    path('diet',views.dietView,name='DietPlan'),
]
