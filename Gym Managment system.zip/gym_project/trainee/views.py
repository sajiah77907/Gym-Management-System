from django.shortcuts import render
import DB as dB

# Create your views here.

def traineeView(request, tid:int=None):
    db = dB.DataBase(username='system',password='sajiahSE20$',port='1521')
    name = db.getRecord('trainee',tid)[0].get('name')
    del(db)
    # name = 'SaJia'
    return render(request,'trainee/trainee.html', context=dict(name=name))

    
def workoutView(request):
    lst = []
    db = dB.DataBase(username='system',password='sajiahSE20$',port='1521')
    lst = db.getWorkout()
    del(db)
    # lst = [
    #     dict(cid=3, tid=1, name='Faris', size=2, time='10:30', ctype='Upper Body'),
    #     dict(cid=3, tid=3, name='Fozan', size=1, time='12:30', ctype='Upper Arms'),
    #     dict(cid=3, tid=1, name='Fahim', size=2, time='15:30', ctype='Chest Weight')
    # ]
    return render(request,'trainee/workout.html', context=dict(items=lst))  


def dietView(request):
    lst = []
    db = dB.DataBase(username='system',password='sajiahSE20$',port='1521')
    lst = db.getDiet()
    del(db)
    # lst = [
    #     dict(did=101, name='Faris', description='''This is the description of diet plan 01'''),
    #     dict(did=102, name='Kamil', description='''This is the description of diet plan 02'''),
    #     dict(did=104, name='Irfan', description='''This is the description of diet plan 03'''),
    # ]
    return render(request,'trainee/Diet Plan.html', context=dict(items=lst))  

