from django.urls import path
from . import views

urlpatterns = [
     path('',views.sessionsView,name='Sessions'),
     path('neworkout/',views.enterWorkout,name='EnterWorkout'),
]