from django.shortcuts import render

# Create your views here.

def sessionsView(request):
    return render(request,'workout/sessions.html')   

def enterWorkout(request):
    trid = request.POST.get('TRAINER ID')
    tid = request.POST.get('TRAINEE ID')
    cid = request.POST.get('CLASS ID')
    size = request.POST.get('CLASS SIZE')
    ctype = request.POST.get('CLASS TYPE')
    time = request.POST.get('CLASS TIME')
    
    
    

