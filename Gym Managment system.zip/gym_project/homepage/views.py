from django.shortcuts import render
from django.http import HttpResponseRedirect, Http404
from django.contrib import messages
import DB as dB

# Create your views here.
passString = 'password'

def checkEmail(email:str):
    import re
    if not re.match(string=email,pattern='.*@.*\..*'):
        return False
    return True

def homeView(request):
    return HttpResponseRedirect('/home/login')

def loginView(request):
    return render(request, 'homepage/signin.html')

def signupView(request):
    return render(request, 'homepage/signup2.html')   

def credentialCheckView(request):
    email = request.POST.get('email')
    password = request.POST.get('password')
    db = dB.DataBase(username='system',password='sajiahSE20$',port='1521')
    lst = db.getCredential(passString)
    del(db)
    # lst = [
    #     {'email':'123@abc.com','password':'123','access':'manager'},
    #     {'email':'456@abc.com','password':'123','access':'trainee'},
    #     {'email':'789@abc.com','password':'123','access':'trainer'},
    # ]
    for r in lst:
        print(r,email,password)
        if r.get('email') == email and r.get('password') == password:
            if r.get('access').lower() == 'manager':
                tid = r.get('tid')
                # mid = 123
                return HttpResponseRedirect(f'/manager/{tid}')
            elif r.get('access').lower() == 'trainee':
                tid = r.get('tid')
                # tid = 456
                return HttpResponseRedirect(f'/trainee/{tid}')
            elif r.get('access').lower() == 'trainer':
                tid = r.get('tid')
                # tid = 789
                return HttpResponseRedirect(f'/trainer/{tid}')
    messages.error(request,'The credentials are not valid')
    return HttpResponseRedirect('/')

def newAccountView(request):
    email = request.POST.get('email')
    password = request.POST.get('password')
    name = request.POST.get('name')
    address = request.POST.get('address')
    fee = request.POST.get('fee')
    joinDate = request.POST.get('date')
    if checkEmail(email):
        from random import randint
        sal=None
        access='trainee'
        mid='7'
        tid = randint(1,9999)
        db = dB.DataBase(username='system',password='sajiahSE20$',port='1521')
        while tid in  db.getTId('trainee'):
            tid = randint(1,9999)
        db.insertRecord(tid, email, password, name, address, mid, joinDate, access, sal, fee)
        del(db)
        messages.success(request, f'Your {access.lower()} {name} is created successfully')
        return HttpResponseRedirect('/home/login')
    messages.error(request, 'The credentials entered are not valid')
    return HttpResponseRedirect('/home/signup')
    
